import numpy
import random

def escoger_movimiento( amenazas ):
    if amenazas != "": #para evitar error en caso de estar muerto
        amenazaSeparada = amenazas.split(":")
        if "-" in amenazaSeparada[0]:
            grado = amenazaSeparada[0].split("-")
        else: #a veces no hay amenazas, por lo que no hay nada que separar
            grado = amenazaSeparada[0]
        cuadrante = amenazaSeparada[1].split("-")
        if "1" in grado or "2" in grado or "3" in grado:
            if grado[1] == "1":
                if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                    movimiento_x = "3"
                    movimiento_y = "0"
                elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                    movimiento_y = "-3"
                    movimiento_x = "0"
                elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                    movimiento_x = "-3"
                    movimiento_y = "0"
                else:
                    movimiento_y = "3"
                    movimiento_x = "0"
            elif grado[1] == "2":
                if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                    movimiento_x = "1"
                    movimiento_y = "0"
                elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                    movimiento_y = "-1"
                    movimiento_x = "0"
                elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                    movimiento_x = "-1"
                    movimiento_y = "0"
                else:
                    movimiento_y = "1"
                    movimiento_x = "0"
            else: #En caso de estar al lado del enemigo, se "arranca"
                if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                    movimiento_x = "0"
                    movimiento_y = "-3"
                elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                    movimiento_y = "0"
                    movimiento_x = "3"
                elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                    movimiento_x = "0"
                    movimiento_y = "3"
                else:
                    movimiento_y = "0"
                    movimiento_x = "-3"
            return movimiento_x + "," + movimiento_y
        else: #Avanza una cantidad random de casillas hacia el cuadrante que haya mas enemigos
            listaNeg = [-3,-2,-1]
            listaPos = [1,2,3]
            if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                movimiento_x = str(random.choice(listaPos))
                movimiento_y = "0"
            elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                movimiento_y = str(random.choice(listaNeg))
                movimiento_x = "0"
            elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                movimiento_x = str(random.choice(listaNeg))
                movimiento_y = "0"
            else:
                movimiento_y = str(random.choice(listaPos))
                movimiento_x = "0"
            return movimiento_x + "," + movimiento_y
    else:
        return "0,1"


def escoger_disparo( amenazas ):
    if amenazas != "":
        amenazaSeparada = amenazas.split(":")
        if "-" in amenazaSeparada[0]:
            grado = amenazaSeparada[0].split("-")
        else:
            grado = amenazaSeparada[0]
        cuadrante = amenazaSeparada[1].split("-")
        if "1" in grado or "2" in grado or "3" in grado:
            if grado[1] == "1":
                listaPOS = [4,5]
                listaNeg = [-4,-5]
                if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                    disparo_x = str(random.choice(listaPOS))
                    disparo_y = "0"
                elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                    disparo_y = str(random.choice(listaNeg))
                    disparo_x = "0"
                elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                    disparo_x = str(random.choice(listaNeg))
                    disparo_y = "0"
                else:
                    disparo_y = str(random.choice(listaPOS))
                    disparo_x = "0"
            elif grado[1] == "2":
                listaPOS = [2,3]
                listaNeg = [-2,-3]
                if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                    disparo_x = str(random.choice(listaPOS))
                    disparo_y = "0"
                elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                    disparo_y = str(random.choice(listaNeg))
                    disparo_x = "0"
                elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                    disparo_x = str(random.choice(listaNeg))
                    disparo_y = "0"
                else:
                    disparo_y = str(random.choice(listaPOS))
                    disparo_x = "0"
            else:
                if cuadrante[0] > cuadrante[1] and cuadrante[0] > cuadrante[2] and cuadrante[0] > cuadrante[3]:
                    disparo_x = "1"
                    disparo_y = "0"
                elif cuadrante[1] > cuadrante[0] and cuadrante[1] > cuadrante[2] and cuadrante[1] > cuadrante[3]:
                    disparo_y = "1"
                    disparo_x = "0"
                elif cuadrante[2] > cuadrante[0] and cuadrante[2] > cuadrante[1] and cuadrante[2] > cuadrante[3]:
                    disparo_x = "1"
                    disparo_y = "0"
                else:
                    disparo_y = "-1"
                    disparo_x = "0"
            return disparo_x + "," + disparo_y
        else: #sino encuentra amenazas hace un disparo random
            xOy = random.choice((0,1))
            lista = [-5,-4,-3,-2,-1,1,2,3,4,5]
            if xOy == 0:
                disparo_x = str(random.choice(lista))
                disparo_y = "0"
            else:
                disparo_x = "0"
                disparo_y = str(random.choice(lista))
            return disparo_x + "," + disparo_y
    else:
        return "0,1"

